//
//  EngineHelper.m
//  Checkmate
//
//  Created by Arsalan majlesi on 9/9/21.
//

#import "EngineManager.h"
#import "EngineController.h"
#import "Util.h"
#include "../Chess/misc.h"



@implementation EngineManager

- (instancetype)init {
    if (self = [super init]) {
        engineController = [[EngineController alloc] initWithGameController: self];
        [engineController setDelegate:self];
        [self startEngine];
    }
   return self;
}

- (void)startEngine {
   [engineController sendCommand: @"uci"];
   [engineController sendCommand: @"isready"];
   [engineController sendCommand: @"ucinewgame"];
   [engineController setPlayStyle: [[Options sharedOptions] playStyle]];
   if ([[Options sharedOptions] permanentBrain])
      [engineController setOption: @"Ponder" value: @"true"];
   else
      [engineController setOption: @"Ponder" value: @"false"];
   [engineController setOption: @"Threads"
                         value: [NSString stringWithFormat: @"%d", [Util CPUCount]]];
#ifdef __LP64__
   // Since we're running on a 64-bit CPU, it's safe to assume that this is a modern
   // device with plenty of RAM, and we can afford a bigger transposition table.
   [engineController setOption: @"Hash" value: @"64"];
#else
   [engineController setOption: @"Hash" value: @"32"];
#endif
   
   [engineController setOption: @"Skill Level" value: [NSString stringWithFormat: @"%d",
                                                       [[Options sharedOptions] strength]]];

   [engineController commitCommands];

}

- (void)didReceiveBestMove:(NSString *)bestMove ponderMove:(NSString *)ponderMove{
    if (_delegate && [_delegate respondsToSelector:@selector(didReceiveBestMove:ponderMove:)]) {
        [_delegate didReceiveBestMove:bestMove ponderMove:ponderMove];
    }
}

- (void)setGameFen:(NSString *)gameFen {
    if (_gameFen != gameFen) {
        _gameFen = gameFen;
        engineController.gameFen = gameFen;
    }
}

- (void)shutdownEngine {
    [engineController shutdownEngine];
}

- (void)startAnalyzing {
    [engineController startAnalyzing];
}

- (void)stopAnalyzing {
    [engineController stopAnalyzing];
}

@end

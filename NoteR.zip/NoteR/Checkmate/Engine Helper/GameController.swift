//
//  GameController.swift
//  Checkmate
//
//  Created by Arsalan majlesi on 9/11/21.
//

import Foundation
import SwiftChess

class GameController: NSObject,EngineManagerDelegate{

    
    static var instance:GameController?
    let engineManager = EngineManager()
    var game = Game()
    var isAnalyzing = false
    var _gameFen:String!
    var bestMove:String?
    var hintDelegate:HintDelegate?
    var dismissHint:DispatchWorkItem?
    var presentHint:DispatchWorkItem?
    var gameFen: String {
        get{
            _gameFen ?? ""
        }
        set(newValue){
            engineManager.gameFen = newValue
            _gameFen = newValue
        }
    }
    override init() {
        super.init()
        engineManager.delegate = self
        gameFen = game.board.fen
        analyze()
        isAnalyzing = engineManager.isAnalyzing
        processHint()
    }

    
    func didReceiveBestMove(_ bestMove: String?, ponderMove: String?) {
        self.bestMove = bestMove
        
    }
    
    
    
    func chessSquaresToTile(squares:String) -> [Tile]{
        let charArray = Array(squares.lowercased())
        func xNumber(_ x:Character) -> Int{
            switch x {
            case "a":
                return 0
            case "b":
                return 1
            case "c":
                return 2
            case "d":
                return 3
            case "e":
                return 4
            case "f":
                return 5
            case "g":
                return 6
            case "h":
                return 7
            default:
                return 0
            }
        }
        let sourceTile = Tile(x:(charArray[1].wholeNumberValue! - 1),y:xNumber(charArray[0]))
        let destinationTile = Tile(x:(charArray[3].wholeNumberValue! - 1),y:xNumber(charArray[2]))
        return [sourceTile,destinationTile]
    }
    
    func move(from:Tile,to:Tile){
        self.hintDelegate?.hideHint()
        isAnalyzing = engineManager.isAnalyzing
      //  DispatchQueue.global(qos: .background).async { [self] in
            if(isAnalyzing){
                engineManager.stopAnalyzing()
            }
            let move = SwiftChess.Move(from: from, to: to)
            game.makeMove(move: move,forced:true)
            gameFen = game.board.fen
            
            analyze()
        
            presentHint?.cancel()
            processHint()
       //}
    }
    
    func processHint(){
        let time = DispatchTime.now() + DispatchTimeInterval.seconds(SKConstants.hintAfter)
        presentHint = DispatchWorkItem {
            guard let bestMove = self.bestMove else {
                debugPrint("Undefined best move to present as hint")
                return
            }
            let tiles = self.chessSquaresToTile(squares: bestMove)
            self.hintDelegate?.showHint(tiles: tiles)
            let hideTime = DispatchTime.now() + DispatchTimeInterval.seconds(SKConstants.hintDuration)
            DispatchQueue.global().asyncAfter(deadline: hideTime) {
                self.hintDelegate?.hideHint()
            }
        }
        DispatchQueue.global().asyncAfter(deadline: time,execute:presentHint!)
        
    }
    func resetGame(){
        game = Game()
        gameFen = game.board.fen
        if isAnalyzing {
            isAnalyzing = false
        }
        self.hintDelegate?.hideHint()
        presentHint?.cancel()
        bestMove = nil
    }
    
    func analyze(){
        engineManager.startAnalyzing()
        isAnalyzing = engineManager.isAnalyzing
        let time = DispatchTime.now() + DispatchTimeInterval.seconds(5)
        DispatchQueue.global().asyncAfter(deadline: time, execute: {
            self.engineManager.stopAnalyzing()
            self.isAnalyzing = self.engineManager.isAnalyzing
        })
    }

  
}

#import <Foundation/Foundation.h>

@interface Util : NSObject

+ (unsigned)CPUCount;
+ (NSString *)translateToFigurine:(NSString *)string;

@end

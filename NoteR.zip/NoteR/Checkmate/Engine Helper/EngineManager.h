//
//  EngineHelper.h
//  Checkmate
//
//  Created by Arsalan majlesi on 9/9/21.
//
#import <Foundation/Foundation.h>
#import "Options.h"
#import "EngineController.h"

@class EngineManager;

@protocol EngineManagerDelegate <NSObject>

- (void)didReceiveBestMove:(nullable NSString *)bestMove ponderMove: (nullable NSString *)ponderMove;

@end

@interface EngineManager: NSObject<EngineControllerDelegate>{
    EngineController *engineController;

}


@property (nonatomic, weak) id<EngineManagerDelegate> delegate;
@property (readonly, nonatomic) BOOL isAnalyzing;
@property (strong, nonatomic, nullable) NSString *gameFen;

- (nonnull instancetype)init;
- (void)startEngine;
- (void)shutdownEngine;

/**
 Informs the internal chess engine to start analyzing the `chessFen`. You should set the `gameFen` before calling this method.
 */
- (void)startAnalyzing;

/**
 Informs the internal chess engine to stop analyzing. And returns the best move and ponder move by delegate.
 */
- (void)stopAnalyzing;

@end

//
//  HintDelegate.swift
//  Checkmate
//
//  Created by Arsalan majlesi on 9/15/21.
//

import Foundation

protocol HintDelegate{
    func showHint(tiles:[Tile])
    func hideHint()
}

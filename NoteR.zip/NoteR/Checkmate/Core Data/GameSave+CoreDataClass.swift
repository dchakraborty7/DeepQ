//
//  GameSave+CoreDataClass.swift
//  Checkmate
//
//  Created by Paul Scott on 12/7/20.
//
//

import Foundation
import CoreData

@objc(GameSave)
public class GameSave: NSManagedObject {

}

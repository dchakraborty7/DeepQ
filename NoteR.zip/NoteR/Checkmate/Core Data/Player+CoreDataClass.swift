//
//  Player+CoreDataClass.swift
//  Checkmate
//
//  Created by Paul Scott on 12/7/20.
//
//

import Foundation
import CoreData

@objc(Player)
public class Player: NSManagedObject {

}

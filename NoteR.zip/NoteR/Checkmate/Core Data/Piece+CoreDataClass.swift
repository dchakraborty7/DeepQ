//
//  Piece+CoreDataClass.swift
//  Checkmate
//
//  Created by Paul Scott on 12/7/20.
//
//

import Foundation
import CoreData

@objc(Piece)
public class Piece: NSManagedObject {

}
